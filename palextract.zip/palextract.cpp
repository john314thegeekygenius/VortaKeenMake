
// g++ -o palextract palextract.cpp

#include <stdio.h>
#include <iostream>
#include <fstream>

int palette[256*4] = {0};

int GB_Colors[4] = {
    0x0f380f,
    0x306230,
    0x8bac0f,
    0x9bbc0f
};
    
void SavePalette(){
	uint16_t color = 0;
	int countd = 0;
	std::cout << "// VGA Palette " << std::endl;
	std::cout << "{" ;
	for(int i = 0; i < 256; i++){
		color = (palette[(i*3)]>>3); // Red
		color |= (palette[(i*3)+1]>>3)<<5; // Green
		color |= (palette[(i*3)+2]>>3)<<10; // Blue
		std::cout << "0x" << std::hex << color << ", ";
		if((countd++) > 16){
			std::cout << std::endl;
			countd = 0;
		}
	}
	std::cout << "}" << std::endl;

	std::cout << "// Greyscale Palette " << std::endl;
	std::cout << "{" ;
	for(int i = 0; i < 256; i++){
		int r = palette[(i*3)]>>3;
		int g = palette[(i*3)+1]>>3;
		int b = palette[(i*3)+2]>>3;
		color = (r+g+b)/3;
		color |= (color<<5);
		color |= (color<<5);
		std::cout << "0x" << std::hex << color << ", ";
		if((countd++) > 16){
			std::cout << std::endl;
			countd = 0;
		}
	}
	std::cout << "}" << std::endl;

	std::cout << "// Gameboy Palette " << std::endl;
	std::cout << "{" ;
	for(int i = 0; i < 256; i++){
		int r = palette[(i*3)]>>3;
		int g = palette[(i*3)+1]>>3;
		int b = palette[(i*3)+2]>>3;
		color = ((r+g+b)/3)>>3;
		r = ((GB_Colors[color]>>16)&0xFF)>>3;
		g = ((GB_Colors[color]>>8)&0xFF)>>3;
		b = ((GB_Colors[color])&0xFF)>>3;
		color = (b<<10)+(g<<5)+r;
		std::cout << "0x" << std::hex << color << ", ";
		if((countd++) > 16){
			std::cout << std::endl;
			countd = 0;
		}
	}
	std::cout << "}" << std::endl;
};

int main(int argc, char *args[]){
	if(argc < 2){
		std::cout << "Use: palextract file.data.pal" << std::endl;
	}
	FILE *fp = fopen(args[1],"rb");
	if(fp==NULL){
		std::cout << "Could not open file " << args[1] << std::endl;
	}
	int pon = 0;
	while(1){
		int b = fgetc(fp);
		if(b==EOF){
			fclose(fp);
			SavePalette();
			return 0;
		}
		palette[pon] |= (unsigned char)b;
		pon += 1;
		if(pon > (256*4)){
			std::cout << "Error reading data." << std::endl;
			return 0;
		}
	}
	return 0;
};

